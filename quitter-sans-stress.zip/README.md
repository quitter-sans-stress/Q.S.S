# Quitter Sans Stress
Service web pour aider à démissionner sans stress.